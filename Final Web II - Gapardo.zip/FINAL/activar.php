<?php
    $id = $_GET['id'];

    $cnx = mysqli_connect ('localhost','root','','gapardo');


    $cslt = "UPDATE usuarios 
            SET ESTADO = 'activo' 
            WHERE ID = '$id'";

    mysqli_query ($cnx, $cslt);
    header ("Location: zonadmin.php");

?>