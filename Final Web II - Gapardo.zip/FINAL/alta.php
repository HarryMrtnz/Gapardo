<?php

    $cnx = mysqli_connect ('localhost', 'root', '', 'gapardo');

    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $clave = $_POST['clave'];

    $cslt = "INSERT INTO usuarios
                SET NOMBRE = '$nombre',
                APELLIDO = '$apellido',
                EMAIL = '$email',
                CLAVE = MD5 ('$clave'),
                NIVEL = 'usuario',
                FECHA_ALTA = NOW( )";
                
    mysqli_query ($cnx, $cslt);
    header ("Location: altauser.php?alta=ok");
?>

