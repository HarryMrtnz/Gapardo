
<!DOCTYPE html>
<html lang="es">
	<head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/estilos.css">
		<title>GRACIAS</title>
	</head>
<body>
    <header>
		<?php include_once("header.php"); ?>

	</header>

    <main id="recibir">
        <div class = "recibir">
            <?php
                    //verificación 
                if(isset($_POST['nombre'])){
                    $nombre = $_POST['nombre'];
                }
                if(isset($_POST['apellido'])){
                    $apellido = $_POST['apellido'];
                }
                if(isset($_POST['email'])){
                    $email = $_POST['email'];
                }
                if(isset($_POST['mensaje'])){
                    $mensaje = $_POST['mensaje'];
                }
                //mensaje de Gracias.
                echo "<div><h3>Hola ".$nombre." ".$apellido."</h3>"
                    ."<p>Gracias por comunicarte con nosotros.</br></p>"
                    ."<p>Tu correo electrónico es: <b>".$email."</b></br></p>"
                    ."<p>Has escrito el siguiente mensaje:</p>"
                    ."<p><b><i>".$mensaje."</i></b></p></div>";

                // variables necesarias de mail.
                $destino = "gabriel.martinez1@davinci.edu.ar";
                $asunto = "Parcial 2";
                $cuerpo = "Nuevo mensaje recibido de: <b>".$nombre." ".$apellido."</b></br>"
                    ."Su correo electrónico es: <b>".$email."</b></br>"
                    ."Y su mensaje fue: <i></br>".$mensaje."</i></br>";
                $cabeceras = "From: $nombre <$email>";
                
                // Sistema de envio del mensaje por mail.
                if (mail($destino, $asunto, $cuerpo, $cabeceras)){ 
                    echo "Tu mensaje fue enviado exitosamente de milagro "
                    ."ya que el smtp no funca y es imposible que se envie el mensaje";

                } else {
                    echo "<div class= 'error'>"
                    ."<p>No se ha podido enviar el mensaje.<br>¡Que mala suerte che! </br>"
                    ."Intentá más tarde a ver que onda.</p>"
                    ."<img src='img/check_no.png' alt='error'></div>";
                    
                    //Lo que llegaría al mail
                    echo "<div class = 'correo'>"
                        ."<b>(NOTA: Lo que tuvo que llegar a destino): </b></br>"
                        .$cuerpo
                        ."</div>";                    
                }
                //Entrar carpeta xampp, php y abrir archivo php.ini, buscar servicio smtp,
                //Descomentar: ;SMTP=localhost , ;smtp_port=25 , ;sendmail_from = me@example.com
            ?>

        </div>
        <div class="back">
                <ul>
                    <a href="contacto.php">VOLVER</a>
                </ul>
        </div>
    </main>

    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

	</footer>
</body>
</html>