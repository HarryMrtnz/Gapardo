<?php           
    $cnx = mysqli_connect('localhost','root','','gapardo' );

    if( isset($_GET["cat"]) ){
        $codigo = $_GET["cat"];
        $cslt = "DELETE FROM categorias 
                WHERE id_categoria = '$codigo'";

        if ( mysqli_query($cnx, $cslt) ){
            header ("Location: panel.php#cat1");		
            
        } else {
            echo "La consulta tiene errores";
        }
    }    
?>
