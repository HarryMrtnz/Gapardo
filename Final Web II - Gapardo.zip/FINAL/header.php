<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>FOOTER</title>
</head>
        <header>
            <div>
                <img src="img/logo_white.png" alt="logo1">
            </div>

            <div>
                <?php

                    $menu = array (
                    'INICIO' => 'index.php',
                    'QUIENES SOMOS'=> 'index.php#quienesomo',
                    'PRODUCTOS'=> 'productos.php',
                    'CONTACTO'=> 'contacto.php');

                    //$menumod = array (
                    //'MODERADOR' =>'moderador.php');

                    $menulogin = array (
                    'INICIAR SESION' => 'loginuser.php',
                    //'REGISTRARSE' =>'altauser.php'
                    );

                    //$cont = count ($menu);
                ?>
            </div>

            <nav>
                <ul>
                    <?php
                    //creación del menú
                    foreach ($menu as $sec => $pag) {
                        echo '<li><a href="'. $pag .'">'. $sec .'</a></li> ';   
                    }

                    //foreach ($menumod as $sec => $pag) {
                    //    echo '<li><a class = "text-center" href="'. $pag .'">'. $sec .'</a></li> '; 
                    //}

                    foreach ($menulogin as $sec => $pag) {
                        echo '<li><a class = "text-center" href="'. $pag .'">'. $sec .'</a></li> '; 
                    }

                    ?>
                </ul>
            </nav>
            
        </header>   
</html>