<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>ALTA CATEGORIA</title>
</head>

<body>
    <header>
        <?php require_once("header.php"); ?>
    </header>

    <main id="altacat">
    <div id = "ok">
            <?php
                $cnx = mysqli_connect('localhost','root','','gapardo' );

                if( isset($_POST["nombreCategoria"]) ){
                    $nombre = $_POST["nombreCategoria"];
                    $tipo = $_POST["tipos"];

                    $cslt = "INSERT INTO categorias (categoria, tipoCategoria) VALUES ('$nombre','$tipo')";
                        
                        if ( mysqli_query($cnx, $cslt) ){    
                            echo '<div class="ok">
                            <div><img src="img/check_yes.png" alt="checkyes"></div> 
                            <div><p>¡Yeah! ¡Nueva categoria agregada!<p>
    
                            <p>Vuelve para visualizar los cambios.<p></div> 
                            <div class="back">
                            <ul>
                                <a href="panel.php#cat1"> VOLVER</a>
                            </ul>
                            </div></div>';			
                        
                        } else {
                            echo "La consulta tiene errores";
                        }                 
                }
            ?>
        </div>
    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
