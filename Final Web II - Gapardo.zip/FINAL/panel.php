<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>PANEL ABM</title>
</head>

<body>
    <header>
        <?php require_once("header.php"); ?>

    </header>

    <main id="panel">
        <?php           
            session_start( );
            
            if( !isset( $_SESSION['ID'] ) ){
                header("Location: index.php?forbidden=1");  
            }          
        ?>
        <div class="salir">
            <a href="logout.php">CERRAR SESION
            <img src="img/salir.png" alt="salir"></a>
        </div>
                            <!-- EDICION DE CATEGORIAS -->
        <h4>AQUI PODRAS MODIFICAR INFORMACION DESDE LA BASE DE DATOS.</h4>

        <div class="panel"> 
            <div id="cat1" class="cat1">
                <h5>EDICION DE CATEGORIAS</h5>
                <table class="tabla-cat">
                <tr><th>CATEGORIAS</th> <th>TIPO</th> <th>OPCIONES</th></tr>
            
                <?php 
                    $cnx = mysqli_connect('localhost','root','','gapardo' );
                    $cslt = "SELECT categorias.id_categoria, categorias.categoria, tipos.nombreTipos
                            FROM categorias INNER JOIN tipos ON id_tipo = tipoCategoria;";

                        if ( $resultado = mysqli_query($cnx, $cslt) ){
                                            
                            while( $fila = mysqli_fetch_array($resultado) ){
                                echo "<tr><td>".$fila["categoria"]."</td>
                                <td>".$fila["nombreTipos"]."</td>
                                <td><a href=\"modifcat.php?cat=".$fila["id_categoria"]."\">MODIFICAR</a> | 
                                <a href=\"borrarcat.php?cat=".$fila["id_categoria"]."\">BORRAR</a></td>
                                </tr>";
                            }                                       
                        
                        } else {
                        echo "Error en la busqueda, intente más tarde.";
                    }                   
                ?>
                </table>
            </div>   
                                        <!-- AGREGAR DE CATEGORIAS -->
            <div class="cat2">
                <h5>AGREGAR NUEVA CATEGORIA</h5> 
                <form action="altacat.php" class="form-control" method="post" name ="cate">
                <input id="nombreCategoria" placeholder="Nombre de la categoría:" class="form-control"
                        type="text" name="nombreCategoria" required/>

                <label for="categoria">Seleccione el tipo de categoría: </label>

                    <?php

                        function listarEnOptions ($tabla, $campoVisible, $id) {

                            $cnx = mysqli_connect('localhost','root','','gapardo' );

                            $cslt = "SELECT * FROM $tabla";
                            if ( $resultado = mysqli_query($cnx, $cslt) ){

                                echo '<select class = "form-control" name = "'.$tabla.'">';

                                while( $fila = mysqli_fetch_array($resultado) ){
                                    echo '<option value="'.$fila["$id"].'">'.$fila["$campoVisible"]."</option>";
                                }
                                
                                echo "</select>";

                            } else {
                                echo "Error en la consulta, revisá el código.";
                            }
                        }

                        listarEnOptions ("tipos","nombreTipos","id_tipo");  
                    ?>

                <input type="submit" id="boton3" value="Agregar" onclick="valida_envia()">

                </form>
            </div>

            <script type="text/javascript">

                    function valida_envia(){
                        if(document.cate.nombreCategoria.value.length==0){
                            alert("Por favor, escriba el nombre de la categoría.")
                            document.cate.nombreCategoria.focus()
                            return 0;
                        }
                    }
            </script>

                                   <!-- EDICION DE INSTRUMENTOS-->
            <div id="tabla-inst">
                <h5>EDICION DE INSTRUMENTOS</h5>
                <table class="tabla-inst">
                    <tr><th>PRODUCTOS</th> <th>OPCIONES</th></tr>

                    <?php
                        $cnslt = "SELECT id_instrumento, nombreInstrumento FROM instrumentos";
                        if ( $resultado = mysqli_query($cnx, $cnslt) ){
                            
                            while( $fila = mysqli_fetch_array($resultado) ){
                                echo "<tr><td>".$fila["nombreInstrumento"]."</td>
                                <td><a href=\"modifprod.php?prod=".$fila["id_instrumento"]."\">MODIFICAR</a> |
                                <a href=\"borrarprod.php?prod=".$fila["id_instrumento"]."\">BORRAR</a></td></tr>\n";
                            }
                            
                        } else {
                            echo "La consulta tiene errores";
                        }
                    ?>
                    
                </table>
            </div>
                                <!-- AGREGAR INSTRUMENTO -->
            <div class="inst2">
                <h5>AGREGA UN NUEVO INSTRUMENTO</h5>
                <form action="altaprod.php" method="post" name ="instrum" enctype="multipart/form-data">
                    <input placeholder="Nombre:" class="form-control" id="nombreInstrumento" type="text" name="nombreInstrumento" required/>
                    <input placeholder="Marca:" class="form-control" id="marcaInstrumento" type="text" name="marcaInstrumento" required/>
                    <textarea placeholder="Descripción:" class="form-control" id="descripcionInstrumento" name="descripcionInstrumento"></textarea>
                    <textarea placeholder="Detalles:" class="form-control" id="detallesInstrumento" name="detallesInstrumento"></textarea>
                    <input placeholder="Precio:" class="form-control" id="precioInstrumento" type="text" name="precioInstrumento" required/>
                    <input placeholder="Cantidad en stock:" class="form-control" id="cantidadInstrumento" type="text" name="cantidadInstrumento" required/>
                    <label for = "fotoInstrumento">Seleccione una imagen del instrumento: </label>
                    <input class="form-control" accept="image/jpeg" id="fotoInstrumento" type="file" name="fotoInstrumento">
                    
                    <label for = "categoria">Seleccione la categoria del instrumento: </label>

                    <?php

                        function listarEnOptions2 ($tabla, $campoVisible, $id) {

                            $cnx = mysqli_connect('localhost','root','','gapardo' );

                            $cslt = "SELECT * FROM $tabla";
                            if ( $resultado = mysqli_query($cnx, $cslt) ){

                                echo '<select class = "form-control" name = "'.$tabla.'">';

                                while( $fila = mysqli_fetch_array($resultado) ){
                                    echo '<option value="'.$fila["$id"].'">'.$fila["$campoVisible"]."</option>";
                                }
                                
                                echo "</select>";

                            } else {
                                echo "Error en la consulta, revisá el código.";
                            }
                        }
                            listarEnOptions2 ("categorias","categoria","id_categoria");
                    ?>

                    <input type="submit" id="boton3" value="Agregar" onclick="valida_envia2()"/>
                </form>
                
                <script>

                    function valida_envia2(){
                        if(document.instrum.nombreInstrumento.value.length==0){
                            alert("Por favor, escriba el nombre del producto.")
                            document.instrum.nombreInstrumento.focus()
                            return 0;
                        }

                        if(document.instrum.marcaInstrumento.value.length==0){
                            alert("Por favor, escriba la marca del producto.")
                            document.instrum.marcaInstrumento.focus()
                            return 0;
                        }

                        if(document.instrum.precioInstrumento.value.length==0){
                            alert("Por favor, escriba el precio del producto.")
                            document.instrum.precioInstrumento.focus()
                            return 0;
                        }

                        if(document.instrum.cantidadInstrumento.value.length==0){
                            alert("Por favor, escriba cantidad en stock del producto.")
                            document.instrum.cantidadInstrumento.focus()
                            return 0;
                        }
                    }
                </script>
                
            </div>
        </div>

        <div class="back">
            <ul>
                <a href="moderador.php"> VOLVER</a>
            </ul>
        </div>   

    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
