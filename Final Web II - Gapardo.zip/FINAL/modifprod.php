<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>MODIFICAR</title>
</head>

<body>
    <header>
        <?php require_once("header.php"); ?>
    </header>

    <main id="modprod">
        <div>
            <?php

                $cnx = mysqli_connect('localhost','root','','gapardo' );       

                if( isset($_GET["prod"]) ){
                $codigo = $_GET["prod"];

                $cslt = "SELECT * FROM instrumentos 
                WHERE id_instrumento = '$codigo'";
    
                    if ( $resultado = mysqli_query($cnx, $cslt) ){
                    $fila = mysqli_fetch_array($resultado);

                    echo '<div class="inst3">
                    <h5>MODIFICA EL PRODUCTO SELECCIONADO</h5>
                    <form action="modifprod.php#ok" method="post" name ="instrum" enctype="multipart/form-data">
                        <input type="hidden" name="id_instrumento" value="'.$fila["id_instrumento"].'">
                        Código número: '.$fila["id_instrumento"].'
                        <input placeholder="Nombre:" class="form-control" id="nombreInstrumento" type="text" name="nombreInstrumento" value="'.$fila["nombreInstrumento"].'">
                        <input placeholder="Marca:" class="form-control" id="marcaInstrumento" type="text" name="marcaInstrumento" value="'.$fila["marcaInstrumento"].'">
                        <textarea placeholder="Descripción:" class="form-control" id="descripcionInstrumento" name="descripcionInstrumento" value="'.$fila["descripcionInstrumento"].'"></textarea>
                        <textarea placeholder="Detalles:" class="form-control" id="detallesInstrumento" name="detallesInstrumento" value="'.$fila["detallesInstrumento"].'"></textarea>
                        <input placeholder="Precio:" class="form-control" id="precioInstrumento" type="text" name="precioInstrumento" value="'.$fila["precioInstrumento"].'">
                        <input placeholder="Cantidad en stock:" class="form-control" id="cantidadInstrumento" type="text" name="cantidadInstrumento" value="'.$fila["cantidadInstrumento"].'">
                        <label for= "fotoInstrumento">Seleccione una imagen del instrumento: </label>
                        <input class="form-control" id="fotoInstrumento" accept="image/jpeg" type="file" name="fotoInstrumento" value="'.$fila["fotoInstrumento"].'>
                        
                        <label for = "categoria">Seleccione la categoria del instrumento: </label>';

                        function listarEnOptions2 ($tabla, $campoVisible, $id) {
                            $cnx = mysqli_connect('localhost','root','','gapardo' );   
                            $cslt = "SELECT * FROM $tabla";
                            if ( $resultado = mysqli_query($cnx, $cslt) ){

                                echo '<select class = "form-control" name = "'.$tabla.'">';

                                while( $fila = mysqli_fetch_array($resultado) ){
                                    echo '<option value="'.$fila["$id"].'">'.$fila["$campoVisible"]."</option>";
                                }
                                
                                echo "</select>";

                            } else {
                                echo "Error en la consulta, revisá el código.";
                            }
                        }
                            listarEnOptions2 ("categorias","categoria","id_categoria");
                        
                        echo '<input class="form-control" id="boton3" type="submit" value="MODIFICAR">
                        </form>';

                    } else {
                        echo "La consulta tiene errores";
                    }
                }

            ?>
            </div>
        </div>
            <!-- confirmacion de modificacion -->
            <div id = "ok">

                <?php
                    $cnx = mysqli_connect('localhost', 'root', '', 'gapardo' );                    
                    if( isset($_POST["nombreInstrumento"]) and isset($_POST["id_instrumento"]) ){

                        $codigo = $_POST["id_instrumento"];
                        $nombre = $_POST["nombreInstrumento"];
                        $marca = $_POST["marcaInstrumento"];
                        $desc = $_POST["descripcionInstrumento"];
                        $detalle = $_POST["detallesInstrumento"];
                        $precio = $_POST["precioInstrumento"];
                        $cant = $_POST["cantidadInstrumento"];
                        $nom_img = $_FILES['fotoInstrumento']['name'];
                        $categoria = $_POST["categorias"];

                        $cslt = "UPDATE instrumentos 
                        SET nombreInstrumento ='$nombre',
                        marcaInstrumento = '$marca',
                        descripcionInstrumento = '$desc',
                        detallesInstrumento = '$detalle', 
                        precioInstrumento = '$precio',
                        cantidadInstrumento = '$cant',
                        fotoInstrumento = '$nom_img',
                        categoriaInstrumento = '$categoria'
                        WHERE id_instrumento = '$codigo'";
                                
                        if ( mysqli_query($cnx, $cslt) ){
                            
                            echo '<div class="ok">
                            <div><img src="img/check_yes.png" alt="checkyes"></div> 
                            <div class= "p1"><p>¡Yeah! ¡Se actualizó el producto correctamente!<p>
                            <p>Vuelve para visualizar los cambios.<p></div> 
                            <div class="back">
                            <ul>
                                <a href="panel.php"> VOLVER</a>
                            </ul>
                            </div></div>';		
                        
                        } else {
                            echo "La consulta tiene errores";
                        }			

                    }
                ?>
        <div class="back">
            <ul>
                <a href="panel.php">VOLVER</a>
            </ul>
        </div> 

    </main>
    
    <footer>
        <?php include_once("footer.html"); ?>
    </footer>
    
</body>
</html>