<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>REGISTRO</title>
</head>

<body>
    <header>
        <?php
            require_once("header.php");

        ?>
    </header>

    <main id="altauser">      
        <?php session_start( ); ?>
   
        <div class="alta">
            <div>
                <h5>REGISTRATE</h5>
                <img src="img/ag_cuenta.png" alt="ag">
            </div>
            <form method="post" action="alta.php" name="alta">
                <p>Ingresa tus datos para registrarte:</p>
                <div><input class="form-control" type="nombre" placeholder="Nombre:" name="nombre" required/></div>
                <div><input class="form-control" type="apellido" placeholder="Apellido:" name="apellido" required/></div>
                <div><input class="form-control" type="email" placeholder="Correo electrónico:" name="email" required/></div>
                <div><input class="form-control" type="password" placeholder="Contraseña:" name="clave" required/></div>

                <div><input type="submit" id="boton3" value="Listo" onclick="valida_envia()"></div>	
            </form>
        
            <script type="text/javascript">

                function valida_envia(){

                    if(document.alta.nombre.value.length==0){
                        alert("Por favor, escriba su nombre.")
                        document.alta.nombre.focus()
                        return 0;
                    }
                    
                    if(document.alta.apellido.value.length==0){
                        alert("Por favor, escriba su apellido.")
                        document.alta.apellido.focus()
                        return 0;
                    }
                
                    if(document.alta.email.value.length==0){
                        alert("Por favor, escriba su correo electrónico.")
                        document.alta.email.focus()
                        return 0;
                    }

                    if(document.alta.clave.value.length==0){
                        alert("Por favor, escriba su contraseña")
                        document.alta.clave.focus()
                        return 0;
                    }
                }
            </script>

            <?php
                if( isset($_GET['alta'])){
                    echo'<img src="img/check_yes.png" alt="checkyes">';
                    echo '<div><h6>¡LISTO! Gracias por registrarte. ¡Ya podés iniciar sesión cuando quieras! </h6><br></div>
                    <div class="log"><ul><a href="loginuser.php">iniciá sesión aquí</a></ul></div>';
                    
                }
            ?>
        </div>
    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
