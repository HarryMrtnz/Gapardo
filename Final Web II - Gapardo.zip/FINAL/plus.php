
<!DOCTYPE html>
<html lang="es">
	<head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/estilos.css">
		<title>PLUS</title>
	</head>
<body>
    <header>
		<?php include_once("header.php"); ?>
	</header>

    <main id="plus">
        <?php            
            session_start( );
            
            if( !isset( $_SESSION['ID'] ) ){
                header("Location: index.php?forbidden=1");  
            }          
        ?>

        <div class="salir">
            <a href="logout.php">CERRAR SESION
            <img src="img/salir.png" alt="salir"></a>
        </div>

        <div class="plus">VIDEO DEMO DE INSTRUMENTOS:

            <!-- Video youtube -->
            <iframe width="560" height="315" 
                src="https://www.youtube.com/embed/Ev7-4De05D4?start=200" 
                title="YouTube video player" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen>

            </iframe>
        </div>

        <div class="back">
            <ul>
                <a href="moderador.php"> VOLVER</a>
            </ul>
        </div>
    </main>

    <footer>
        <?php include_once("footer.html"); ?>
	</footer>
</body>
</html>