<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INICIO</title>
</head>

<body>
    <header>
        <?php
            require_once("header.php");

        ?>

    </header>

    <main>
        <div class = "instrums">
            <img src="img/instrums.png" alt="portada">
        </div>
        <h2 id="quienesomo">QUIENES SOMOS:</h2>
        <div class= "somos">
            <div class="historia">
                    
                <h3>NUESTRA HISTORIA</h3>
                <p>A principios del 2020, comienza el proyecto de abrir nuestro primer local de instrumentos musicales, ofeciendo equilibrio en calidad y precio, tanto a estudiantes como a profesionales. Lamentablemente, en Marzo llego el COVID19, el cual hizo que los planes no se llebaran a cabo, demorando la apertura del local, el cual abrio en Julio 2021 con tal éxito repentino, permitiendonos abrir dos locales más.</p>

                <p>En Mayo 2022 abre esta página web. Aquí encontrarás todos los instrumentos musicales que ofresemos en nuestros locales y hacernos pedidos de otros instrumentos que no tengamos, también ponerte en contacto con nosotros para despejarte de cualquier duda o contarnos tus opiniones y sugerencias. </p>
                
            </div>

            <div class="mision">
            <h3>MISIÓN Y VISIÓN</h3>
                <p>Nuestra misión es brindar a nuestros clientes la mejor experiencia al adquirir instrumentos musicales, logrando la conformidad con profesionalismo.</p>
                
                <p>Nuestra vision es convertirnos en la tienda de instrumentos musicales mas grande del país ofreciendo los mejores productos de calidad.</p>
                
            </div>
        </div>
    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
