<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>MODIFCAR CATEGORIA</title>
</head>

<body>
    <header>
        <?php require_once("header.php"); ?>
    </header>

    <main id="modcat">
        <div>

            <?php
            
                $cnx = mysqli_connect('localhost','root','','gapardo' );

                if( isset($_GET["cat"]) ){
                $codigo = $_GET["cat"];

                $cslt = "SELECT * FROM categorias WHERE id_categoria='$codigo'";

                    if ( $resultado = mysqli_query($cnx, $cslt) ){
                        $fila = mysqli_fetch_array($resultado);
                        
                        echo '<div class="modcat">Renombrar categoría:
                        <form action = "modifcat.php#ok" method="post">
                        <input type="text" class="form-control" name="nombreCat" value="'.$fila["categoria"].'">
                        <input type="hidden" name="codigoCat" value="'.$fila["id_categoria"].'">
                        
                        <label for="tipos">Seleccione el tipo de categoría: </label>';

                        function listarEnOptions ($tabla, $campoVisible, $id) {

                            $cnx = mysqli_connect('localhost','root','','gapardo' );
                            $cslt = "SELECT * FROM $tabla";
                            if ( $resultado = mysqli_query($cnx, $cslt) ){

                                echo '<select class = "form-control" name = "'.$tabla.'">';

                                while( $fila = mysqli_fetch_array($resultado) ){
                                    echo '<option value="'.$fila["$id"].'">'.$fila["$campoVisible"]."</option>";
                                }
                                
                                echo "</select>";

                            } else {
                                echo "Error en la consulta, revisá el código.";
                            }
                        }
                        listarEnOptions ("tipos","nombreTipos","id_tipo");
                    
                        echo '<input type="submit" id="boton3" value="MODIFICAR"></form>';

                    } else {
                        echo "La consulta tiene errores";
                    }
                }
            ?>
            </div>
        </div>
            <!-- confirmacion de modificacion -->
        <div id = "ok1">

            <?php             
                if( isset($_POST["nombreCat"]) and isset($_POST["codigoCat"]) ){
                    $nombre = $_POST["nombreCat"];
                    $codigo = $_POST["codigoCat"];
                    $tipo = $_POST["tipos"];
                
                    $cslt = "UPDATE categorias
                        SET categoria = '$nombre', 
                            tipoCategoria = '$tipo'
                        WHERE id_categoria ='$codigo'";
                    
                    if ( mysqli_query($cnx, $cslt) ){
                            
                        echo '<div class="ok">
                        <div><img src="img/check_yes.png" alt="checkyes"></div> 
                        <div class= "p1"><p>¡Yeah! ¡Se actualizó la categoria correctamente!<p>
                        <p>Vuelve para visualizar los cambios.<p></div> 
                        <div class="back">
                        <ul>
                            <a href="panel.php"> VOLVER</a>
                        </ul>
                        </div></div>';		
                    
                    } else {
                        echo "La consulta tiene errores";
                    }
                }
            ?>
        </div>
        <div class="back">
            <ul>
                <a href="panel.php">VOLVER</a>
            </ul>
        </div> 

    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
