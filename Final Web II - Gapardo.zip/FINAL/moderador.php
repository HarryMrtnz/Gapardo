<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>LOGIN</title>
</head>

<body>
    <header>
        <?php
            require_once("header.php");

        ?>

    </header>

    <main id="mod" >
        <?php 
            session_start( );
            
            if( !isset( $_SESSION['ID'] ) ){
                header("Location: moderador.php?forbidden=1");  
            }            
        ?>
        <div class="salir">
            <a href="logout.php">CERRAR SESION
            <img src="img/salir.png" alt="salir"></a>
        </div>

        <div class="mod">
            <div>
                <a href="panel.php"><img src="img/panel.png" alt="panel"></a>
                <h2>PANEL ABM</h2>
            </div>
            <div>
                <a href="plus.php"><img src="img/video.png" alt="video"></a>
                <h2>VIDEOS DEMO</h2>
            </div>
            <div>
                <a href="zonadmin.php"><img src="img/users.png" alt="users"></a>
                <h2>ZONA ADMIN</h2>
            </div>
        </div>
    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
