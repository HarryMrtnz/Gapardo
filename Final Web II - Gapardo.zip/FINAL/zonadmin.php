<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>ADMINS</title>
</head>

<body>
    <header>
        <?php require_once("header.php"); ?>
    </header>

    <main id="admin">
        <?php
            session_start( );

            if( !isset($_SESSION['NIVEL']) || $_SESSION['NIVEL'] != 'Admin' ){
                
                die ('<div class = "die">
                    <div><img src="img/stop.png" alt="stop"></div>
                    <div class ="stop"><b>ACCESO DENEGADO.</b><br><br> 
                                    NO TENES LOS PERMISOS NECESARIOS.</div>
                    <div class = "back">
                        <ul><a href="moderador.php"> VOLVER</a>
                    </ul></div></div>
                    
                <footer>            
                    <nav>
                        <h5>SEGUINOS EN NUESTRAS REDES SOCIALES:</h5>
                        <ul>
                            <li><a href="https://www.facebook.com" target="new">
                            <img src="img/facebook.png" alt="facebook_icono"></a></li>
                            <li><a href="https://instagram.com" target="new">
                            <img src="img/instagram.png" alt="instagram_icono"></a></li>
                            <li><a href="https://twitter.com" target="new">
                            <img src="img/twitter.png" alt="twitter_icono"></a></li>
                        </ul>
                    </nav>                     
                    <div>
                        <p> Final - Programación Web II - Harry &copy; copyright - 2022</p>
                    </div>                
        
                </footer>');
            }

            $cnx = mysqli_connect ('localhost','root','','gapardo');

            $cslt = "SELECT ID, NIVEL, IFNULL(NOMBRE, '----') AS NOMBRE, ESTADO, 
                    IFNULL(APELLIDO, '----') AS APELLIDO, EMAIL, 
                    DATE_FORMAT( FECHA_ALTA, '%d/%m/%Y' ) AS FECHA 
                    FROM usuarios ORDER BY FECHA_ALTA DESC";

            $resultado = mysqli_query($cnx, $cslt);
        ?>

        <div class="admin">
            <div class="salir">
                <a href="logout.php">CERRAR SESION
                <img src="img/salir.png" alt="salir"></a>
            </div>

            <h5>LISTA DE PERSONAS REGISTRADAS:</h5>

            <table class="tabla-users">
                <tr>
                    <th>NOMBRE</th>
                    <th>APELLIDO</th>
                    <th>EMAIL</th>
                    <th>NIVEL</th>
                    <th>FECHA</th>
                    <th>ESTADO</th>
                    <th>OPCIONES</th>
                </tr>

                <?php
                    while($a = mysqli_fetch_assoc ($resultado)){
                    
                        echo "<tr>
                                <td>".$a['NOMBRE']."</td>
                                <td>".$a['APELLIDO']."</td>
                                <td>".$a['EMAIL']."</td>
                                <td>".$a['NIVEL']."</td>
                                <td>".$a['FECHA']."</td>
                                <td>".$a['ESTADO']."</td>
                        
                                 <td>";
                        
                                if( $a['ESTADO'] == 'activo' ){
                                    echo '<a href="bannear.php?id='.$a['ID'].'">BANNEAR</a>';
                                }else{
                                
                                    echo '<a href="activar.php?id='.$a['ID'].'">ACTIVAR</a>';
                                
                                }

                                echo ' | ';
                                
                                if( $a['NIVEL'] == 'usuario' ){
                                    echo '<a href="daradmin.php?id='.$a['ID'].'">HACER ADMIN</a>';
                                }else{
                                    echo '<a href="daruser.php?id='.$a['ID'].'">HACER USUARIO</a>';
                                }
                            
                        echo '</td>
                        </tr>';                
                    }
                ?>	
            </table>

        </div>

            <div class="back">
                <ul>
                    <a href="moderador.php">VOLVER</a>
                </ul>
            </div>
    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
