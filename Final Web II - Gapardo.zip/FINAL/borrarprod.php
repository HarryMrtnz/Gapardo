<?php      
    $cnx = mysqli_connect('localhost','root','','gapardo' );

    if( isset($_GET["prod"]) ){
        $codigo = $_GET["prod"];
        $cslt = "DELETE FROM instrumentos WHERE id_instrumento = '$codigo'";

        if ( mysqli_query($cnx, $cslt) ){
            header ("Location: panel.php#tabla-inst");		
            
        } else {
            echo "La consulta tiene errores";
        }
    }
?>

