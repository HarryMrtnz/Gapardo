
<!DOCTYPE html>
<html lang="es">
	<head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/estilos.css">
		<title>CONDICIONES</title>
	</head>
<body>
    <header>
		<?php 
			include_once("header.php");

		?>

	</header>

    <main id="terminos">
        <div>
            <h2>TERMINOS Y CONDICIONES</h1>

            <div>
                <p><b>1</b>. No usar palabras ofensivas.</br>
                Podria herir los sentimientos de quien lea el mensaje enviado.</p></br>

                <p><b>2</b>. No hacer spam.</br>
                Evite mandar varios mensajes en un corto periodo de tiempo, tenga paciencia en la respuesta de su mensaje.</p></br>

                <p><b>3</b>. Cambios en los términos.</br>
                Pueden cambiar estos Términos y condiciones cuando sea necesario.</p></br>

                <p><b>Última actualización: 01 de Agosto de 2022.</b></P>

            </div>

            <div class="back">
                <ul>
                    <a href="contacto.php">VOLVER</a>
                </ul>
            </div>
        </div>


    </main>

    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

	</footer>
</body>
</html>