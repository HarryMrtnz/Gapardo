<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>ALTA PRODUCTO</title>
</head>

<body>
    <header>
        <?php
            require_once("header.php");

        ?>

    </header>

    <main id="altaprod">
        <div class="altaprod">

            <?php
            $cnx = mysqli_connect('localhost','root','','gapardo' );

                if( isset($_POST["nombreInstrumento"]) ){
                    
                    $nombre = $_POST["nombreInstrumento"];
                    $marca = $_POST["marcaInstrumento"];
                    $desc = $_POST["descripcionInstrumento"];
                    $detalle = $_POST["detallesInstrumento"];
                    $precio = $_POST["precioInstrumento"];
                    $cantidad = $_POST["cantidadInstrumento"];
                    $categoria = $_POST["categorias"];
                    //$original = imagecreatefromjpeg($_FILES['fotoInstrumento']['tmp_name']);
                    //$original = addslashes(file_get_contents ($_FILES['fotoInstrumento']['tmp_name']));

                        //Guardo datos de la imagen en variables.
                        $nom_img = $_FILES['fotoInstrumento']['name'];
                        $tipo_img = $_FILES['fotoInstrumento']['type'];
                        $size_img = $_FILES['fotoInstrumento']['size'];
                        $file_img = $_FILES['fotoInstrumento']['tmp_name'];
                        $error_img = $_FILES['fotoInstrumento']['error'];

                        //Mover imagen a la carpeta "fotitos".
                        move_uploaded_file($_FILES['fotoInstrumento']['tmp_name'],
                                'fotitos/'.$_FILES['fotoInstrumento']['name']);
                    
                    $cslt = "INSERT INTO instrumentos (nombreInstrumento, marcaInstrumento, 
                    descripcionInstrumento, detallesInstrumento, precioInstrumento, 
                    cantidadInstrumento, fotoInstrumento, categoriaInstrumento) 
                    VALUES ( '$nombre', '$marca', '$desc', '$detalle', '$precio', '$cantidad', '$nom_img', '$categoria')";
                
                if ( mysqli_query($cnx, $cslt) ){
                        
                    echo '<div class="ok">
                    <div><img src="img/check_yes.png" alt="checkyes"></div> 
                    <div class= "p1"><p>¡Yeah! ¡Agregaste el producto correctamente!<p>
                    <p>Vuelve para visualizar los cambios.<p></div> 
                    <div class="back">
                    <ul>
                        <a href="panel.php#tabla-inst"> VOLVER</a>
                    </ul>
                    </div></div>';		
                
                    } else {
                    echo "La consulta tiene errores";
                    }
                }

            ?>
        </div>
    </main>
    
    <footer>
        <?php 
            include_once("footer.html");
        
        ?>

    </footer>
    
</body>
</html>
