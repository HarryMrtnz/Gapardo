<?php
    $id = $_GET['id'];

    $cnx = mysqli_connect('localhost','root','','gapardo');


    $cslt = "UPDATE usuarios 
            SET NIVEL = 'usuario' 
            WHERE ID = '$id'";

    mysqli_query ($cnx, $cslt);
    header ("Location: zonadmin.php");

?>