<?php
    session_start( );

    $cnx = mysqli_connect('localhost','root','','gapardo');

    $email = $_POST['email'];
    $clave = $_POST['clave'];

    $cslt = "SELECT NOMBRE, APELLIDO, EMAIL, ID, NIVEL 
            FROM usuarios 
            WHERE EMAIL= '$email' 
            AND CLAVE = MD5 ('$clave') 
            LIMIT 1 ";

    $f = mysqli_query ($cnx, $cslt);
    $a = mysqli_fetch_assoc ($f);

    if( $a == NULL ){
        header("Location: loginuser.php?login=error");

    }else{
        $_SESSION = $a;
        
        header("Location: moderador.php");
    }
?>

