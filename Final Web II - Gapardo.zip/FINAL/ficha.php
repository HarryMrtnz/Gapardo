<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>FICHA</title>
</head>

<body>
	<header>
        <?php
            require_once("header.php");

        ?>

    </header>

	<main id="ficha">		
		<?php
	
			$cnx = mysqli_connect('localhost','root','','gapardo' );
			if( isset($_GET["prod"]) ){
			$codigo = $_GET["prod"];

			$cslt = "SELECT * FROM instrumentos WHERE id_instrumento = '$codigo'";
				if ( $resultado = mysqli_query($cnx, $cslt) ){
									
					while( $fila = mysqli_fetch_array($resultado) ){
						echo '<div class="ficha">
						<h3>'.$fila["nombreInstrumento"].'</h3>
						<div class="fichaimg"> <img src="fotitos/'.$fila["fotoInstrumento"].'" alt="imagen_producto"></div>
						<div class="info"><h5>MARCA:</h5>
							<p>'.$fila["marcaInstrumento"].'</p>
						<h5>DESCRIPCIÓN:</h5>
							<p>'.$fila["descripcionInstrumento"].'</p>
						<h5>DETALLE:</h5> 
							<p>'.$fila["detallesInstrumento"].'</p>
						<h5>CANTIDAD DISPONIBLE:</h5>
							<p>'.$fila["cantidadInstrumento"].' unidades</p>
						<h5>PRECIO CONTADO:</h5>
						<h5><b>$'.$fila["precioInstrumento"].'</b></h5></div></div>';
					}
				}
			}		
		?>

		<div class="back">
			<ul>
				<a href="productos.php"> VOLVER</a>
			</ul>
		</div>   
	</main>
	
	<footer>
			<?php 
				include_once("footer.html");
			
			?>
	</footer>
</body>
</html>