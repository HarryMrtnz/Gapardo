<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/estilos.css">
    <title>PRODUCTOS</title>
</head>
<body>
    <header>
		<?php include_once("header.php"); ?>
	</header>

    <main id="productos">
<!-- Fila 1 -->        
        <div class="productos">
            <h1>PRODUCTOS</h1>

            <div>
                <a href="productos.php?tipo=1#cates">
                <img src="img/cuerdas.jpg" alt="cuerdas" class="img-fluid"></a>
            </div>
            <div>
                <a href="productos.php?tipo=2#cates">
                <img src="img/vientos.jpg" alt="vientos" class="img-fluid"></a>
            </div>
            <div>
                <a href="productos.php?tipo=3#cates">
                <img src="img/percusion.jpg" alt="percusion" class="img-fluid"></a>
            </div>
            <div>
                <a href="productos.php?tipo=4#cates">
                <img src="img/otros.jpg" alt="otros" class="img-fluid"></a>                
            </div>
                <!-- Fila 2 -->
            <div id="cates" class="categorias">
                <?php 

                    $cnx = mysqli_connect('localhost','root','','gapardo' );
                    $cslt = "SELECT * FROM categorias";

                    if ( $resultado = mysqli_query($cnx, $cslt) ){

                        echo '<ul><h3>CATEGORIAS</h3>';
                        while( $fila = mysqli_fetch_array($resultado) ){
                            echo "<li>
                            <a href='productos.php?cat=".$fila["id_categoria"]."#cates'>".$fila["categoria"]."</a>
                            </li>";
                        }
                        echo "</ul>";
                        
                    } else {
                        echo "Error en la busqueda, intente más tarde.";
                    }                   
                ?> 
            </div>
<!-- Fila 3 -->
            <div class="prods">
                <?php
                    if( isset($_GET["tipo"]) ){
                        $codigo = $_GET["tipo"];

                        $cslt = "SELECT id_instrumento, nombreInstrumento, precioInstrumento, fotoInstrumento 
                        FROM instrumentos 
                        INNER JOIN categorias ON id_categoria = categoriaInstrumento
                        INNER JOIN tipos ON id_tipo = tipoCategoria
                        WHERE id_tipo = '$codigo'";

                        if ( $resultado = mysqli_query($cnx, $cslt) ){

                            while( $fila = mysqli_fetch_array($resultado) ){

                                echo '<div class="items"><nav><ul><li>
                                    <a href="ficha.php?prod='.$fila['id_instrumento'].'">'
                                    .$fila['nombreInstrumento'].'
                                    <p class="precio">Precio: $'.$fila['precioInstrumento'].'</p><br>
                                    <img src="fotitos/'.$fila["fotoInstrumento"].'" alt="imagen_producto">
                                    </a></li></ul></nav></div>';
                            }
                            
                        } else {
                            echo "La consulta tiene errores";
                        }                     
                    }

                    if( isset($_GET["cat"]) ){
                    $codigo = $_GET["cat"];

                    $cslt = "SELECT id_instrumento, nombreInstrumento, precioInstrumento, fotoInstrumento 
                            FROM instrumentos 
                            WHERE categoriaInstrumento ='$codigo'";

                        if ( $resultado = mysqli_query($cnx, $cslt) ){
                                         
                            while( $fila = mysqli_fetch_array($resultado) ){

                                echo '<div class="items"><nav><ul><li>
                                    <a href="ficha.php?prod='.$fila['id_instrumento'].'">'
                                    .$fila['nombreInstrumento'].'
                                    <p = class="precio">Precio: $'.$fila['precioInstrumento'].'</p><br>
                                    <img src="fotitos/'.$fila["fotoInstrumento"].'" alt="imagen_producto">
                                    </a></li></ul></nav></div>';
                            }                         
                        } else {
                            echo "La consulta tiene errores";
                        }
                    }
                ?>  

            </div>
        </div>

        <div class="back">
            <ul>
                <a href="index.php"> VOLVER</a>
            </ul>
        </div> 

    </main>

    <footer>
        <?php include_once("footer.html"); ?>
	</footer>    
</body>
</html>